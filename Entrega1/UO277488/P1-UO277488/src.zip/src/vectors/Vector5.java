package vectors;

/**
 * This program serves to measure times automatically increasing the size of the
 * problem. In addition, we use a repetition value determined by nTimes, an
 * argument of the program
 */
public class Vector5 {
	static int[] v;

	public static void main(String arg[]) {
		int repetitions = Integer.parseInt(arg[0]);
		long t1, t2;
		int maximumPos = 0;
		int maximumVal = 0;

		for (int n=10000; n<=81920000 ; n*=2) { // n is increased *2
			v = new int[n];
			Vector1.fillIn(v);

			t1 = System.currentTimeMillis();
			// We have to repeat the whole process to be measured
			for (int repetition = 1; repetition <= repetitions; repetition++) {
				int[] w = new int[2];
				Vector1.maximum(v, w);
				maximumPos = w[0];
				maximumVal = w[1];
			}
			t2 = System.currentTimeMillis();
			System.out.printf("SIZE=%d TIME=%d milliseconds MAXIMUM VALUE=%d MAXPOS=%d"
					+ " NTIMES=%d\n", n, t2 - t1, maximumVal, maximumPos, repetitions);
		} // for

	}// main

}